package dashboard

// Placeholder package so internal/dashboard builds.
// Main dashboard HTTP server entrypoint is in cmd/dashboard/main.go.
